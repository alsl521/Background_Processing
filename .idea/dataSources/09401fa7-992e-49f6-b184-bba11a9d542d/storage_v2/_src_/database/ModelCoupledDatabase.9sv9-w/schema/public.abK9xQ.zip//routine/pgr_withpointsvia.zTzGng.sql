create function pgr_withpointsvia(text, text, anyarray, directed boolean DEFAULT true, strict boolean DEFAULT false, u_turn_on_edge boolean DEFAULT true, driving_side character DEFAULT 'b'::bpchar, details boolean DEFAULT false, OUT seq integer, OUT path_id integer, OUT path_seq integer, OUT start_vid bigint, OUT end_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision, OUT route_agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
  SELECT seq, path_id, path_seq, start_vid, end_vid, node, edge, cost, agg_cost, route_agg_cost
  FROM _pgr_withPointsVia( _pgr_get_statement($1), _pgr_get_statement($2), $3, $4, $5, $6, $7, $8);
$$;

comment on function pgr_withpointsvia(text, text, anyarray, boolean, boolean, boolean, char, boolean, out integer, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision, out double precision) is 'pgr_withPointsVia
- PROPOSED
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
  - Points SQL with columns: [pid], edge_id, fraction [,side]
  - ARRAY[via vertices identifiers]
- Optional Parameters
  - directed := true
  - strict := false
  - U_turn_on_edge := true
  - driving_side := ''b''
  - details := ''false''
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_withPointsVia.html
';

alter function pgr_withpointsvia(text, text, anyarray, boolean, boolean, boolean, char, boolean, out integer, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision, out double precision) owner to postgres;

