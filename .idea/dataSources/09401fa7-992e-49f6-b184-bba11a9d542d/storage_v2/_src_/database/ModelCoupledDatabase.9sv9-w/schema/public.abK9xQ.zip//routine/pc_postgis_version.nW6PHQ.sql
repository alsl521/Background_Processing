create function pc_postgis_version() returns text
    immutable
    strict
    language sql
as
$$ SELECT '1.2.4'::text $$;

alter function pc_postgis_version() owner to postgres;

