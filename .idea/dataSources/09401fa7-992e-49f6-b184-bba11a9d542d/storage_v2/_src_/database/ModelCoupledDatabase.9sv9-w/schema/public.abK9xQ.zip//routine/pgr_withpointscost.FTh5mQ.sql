create function pgr_withpointscost(text, text, bigint, anyarray, directed boolean DEFAULT true, driving_side character DEFAULT 'b'::bpchar, OUT start_pid bigint, OUT end_pid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT $3, a.end_pid, a.agg_cost
    FROM _pgr_withPoints(_pgr_get_statement($1), $2, ARRAY[$3]::BIGINT[], $4::BIGINT[], $5, $6, TRUE, TRUE) AS a;
$$;

comment on function pgr_withpointscost(text, text, bigint, anyarray, boolean, char, out bigint, out bigint, out double precision) is 'pgr_withPointsCost (One to Many)
- PROPOSED
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - Points SQL with columns: [pid], edge_id, fraction[,side]
    - From vertex/point identifier
    - To ARRAY[vertices/points identifiers]
- Optional Parameters
    - directed := ''true''
    - driving_side := ''b''
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_withPointsCost.html
';

alter function pgr_withpointscost(text, text, bigint, anyarray, boolean, char, out bigint, out bigint, out double precision) owner to postgres;

