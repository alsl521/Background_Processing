create function pc_version() returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
	libver TEXT;
	scrver TEXT;
	version TEXT;
BEGIN
	libver := public.pc_lib_version();
	scrver := public.pc_script_version();
	version := public._pc_version_no_commit(libver, scrver);
	RETURN version;
END;
$$;

alter function pc_version() owner to postgres;

