create function pc_intersection(pcpatch, geometry) returns pcpatch
    language sql
as
$$
		WITH
			 pts AS (SELECT public.PC_Explode($1) AS pt),
		   pgpts AS (SELECT public.ST_GeomFromEWKB(public.PC_AsBinary(pt)) AS pgpt, pt FROM pts),
			ipts AS (SELECT pt FROM pgpts WHERE public.ST_Intersects(pgpt, $2)),
			ipch AS (SELECT public.PC_Patch(pt) AS pch FROM ipts)
		SELECT pch FROM ipch;
	$$;

alter function pc_intersection(pcpatch, geometry) owner to postgres;

