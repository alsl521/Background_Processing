create function pc_intersects(pcpatch, geometry) returns boolean
    language sql
as
$$
		SELECT public.ST_Intersects($2, public.PC_EnvelopeGeometry($1))
	$$;

alter function pc_intersects(pcpatch, geometry) owner to postgres;

