create function pgr_edgedisjointpaths(text, bigint, anyarray, directed boolean DEFAULT true, OUT seq integer, OUT path_id integer, OUT path_seq integer, OUT end_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, path_id, path_seq, end_vid, node, edge, cost, agg_cost
    FROM _pgr_edgeDisjointPaths(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], $4);
  $$;

comment on function pgr_edgedisjointpaths(text, bigint, anyarray, boolean, out integer, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_edgeDisjointPaths(One to Many)
 - Parameters:
   - dges SQL with columns: id, source, target, cost [,reverse_cost]
   - From vertex identifier
   - to ARRAY[vertices identifiers]
- Optional Parameters
   - directed := true
- Documentation:
   - https://docs.pgrouting.org/latest/en/pgr_edgeDisjointPaths.html
';

alter function pgr_edgedisjointpaths(text, bigint, anyarray, boolean, out integer, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

