create function pgr_isplanar(text) returns boolean
    strict
    language sql
as
$$
    SELECT _pgr_isPlanar(_pgr_get_statement($1));
$$;

comment on function pgr_isplanar(text) is 'pgr_isPlanar
- EXPERIMENTAL
- Undirected graph
- Parameters:
  - edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_isPlanar.html
';

alter function pgr_isplanar(text) owner to postgres;

