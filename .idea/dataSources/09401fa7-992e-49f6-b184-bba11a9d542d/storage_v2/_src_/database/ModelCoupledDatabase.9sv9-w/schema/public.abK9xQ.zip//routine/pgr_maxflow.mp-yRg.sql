create function pgr_maxflow(text, anyarray, anyarray) returns bigint
    strict
    language sql
as
$$
        SELECT flow
        FROM _pgr_maxflow(_pgr_get_statement($1), $2::BIGINT[], $3::BIGINT[], algorithm := 1, only_flow := true);
  $$;

comment on function pgr_maxflow(text, anyarray, anyarray) is 'pgr_maxFlow(Many to Many)
- Directed graph
- Parameters:
  - edges SQL with columns: id, source, target, capacity [,reverse_capacity]
  - from ARRAY[vertices identifiers]
  - to ARRAY[vertices identifiers]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_maxFlow.html
';

alter function pgr_maxflow(text, anyarray, anyarray) owner to postgres;

