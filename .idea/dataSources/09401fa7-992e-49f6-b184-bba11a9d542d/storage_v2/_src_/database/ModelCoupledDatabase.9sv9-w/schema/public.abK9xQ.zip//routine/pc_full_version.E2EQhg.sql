create function pc_full_version() returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
	pcver TEXT;
	pclibver TEXT;
	pcscrver TEXT;
	pgsqlver TEXT;
	libxml2ver TEXT;
	lazperfenabled BOOLEAN;
BEGIN
	pclibver := public.pc_lib_version();
	pcscrver := public.pc_script_version();
	pcver := public._pc_version_no_commit(pclibver, pcscrver);
	pgsqlver := public.pc_pgsql_version();
	libxml2ver := public.pc_libxml2_version();
	lazperfenabled := public.pc_lazperf_enabled();
	RETURN 'POINTCLOUD="' || pclibver || '" PGSQL="' || pgsqlver || '" LIBXML2="' || libxml2ver ||
		' LAZPERF enabled=' || lazperfenabled;
END;
$$;

alter function pc_full_version() owner to postgres;

