create function pgr_withpointsksp(text, text, anyarray, bigint, integer, character, directed boolean DEFAULT true, heap_paths boolean DEFAULT false, details boolean DEFAULT false, OUT seq integer, OUT path_id integer, OUT path_seq integer, OUT start_vid bigint, OUT end_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, path_id, path_seq, start_vid, end_vid, node, edge, cost, agg_cost
    FROM _pgr_withPointsKSP(_pgr_get_statement($1), _pgr_get_statement($2), $3::BIGINT[], ARRAY[$4]::BIGINT[], $5, $6, $7, $8, $9, true);
$$;

comment on function pgr_withpointsksp(text, text, anyarray, bigint, integer, char, boolean, boolean, boolean, out integer, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_withPointsKSP
- PROPOSED
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - Points SQL with columns: [pid], edge_id, fraction[,side]
    - From ARRAY[vertices identifier]
    - To vertex identifier
    - K
    - driving side
- Optional Parameters
    - directed := true
    - heap paths := false
    - details := false
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_withPointsKSP.html';

alter function pgr_withpointsksp(text, text, anyarray, bigint, integer, char, boolean, boolean, boolean, out integer, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

