create function pgr_bipartite(text, OUT vertex_id bigint, OUT color_id bigint) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT node, color
    FROM _pgr_bipartite(_pgr_get_statement($1));
END;
$$;

comment on function pgr_bipartite(text, out bigint, out bigint) is 'pgr_bipartite
- EXPERIMENTAL
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_bipartite.html
';

alter function pgr_bipartite(text, out bigint, out bigint) owner to postgres;

