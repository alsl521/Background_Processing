create function pgr_maxcardinalitymatch(text, directed boolean, OUT seq integer, OUT edge bigint, OUT source bigint, OUT target bigint) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
RAISE WARNING 'pgr_maxCardinalityMatch(text,boolean) deprecated signature on v3.4.0';
RETURN QUERY SELECT a.seq, a.edge, a.source, a.target
FROM _pgr_maxCardinalityMatch(_pgr_get_statement($1), $2) AS a;
END
$$;

comment on function pgr_maxcardinalitymatch(text, boolean, out integer, out bigint, out bigint, out bigint) is 'pgr_maxCardinalityMatch deprecated signature on v3.4.0
- Documentation: https://docs.pgrouting.org/latest/en/pgr_maxCardinalityMatch.html';

alter function pgr_maxcardinalitymatch(text, boolean, out integer, out bigint, out bigint, out bigint) owner to postgres;

