create function pgr_pushrelabel(text, bigint, bigint, OUT seq integer, OUT edge bigint, OUT start_vid bigint, OUT end_vid bigint, OUT flow bigint, OUT residual_capacity bigint) returns SETOF record
    strict
    language sql
as
$$
        SELECT seq, edge_id, source, target, flow, residual_capacity
        FROM _pgr_maxflow(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], ARRAY[$3]::BIGINT[], 1);
  $$;

comment on function pgr_pushrelabel(text, bigint, bigint, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) is 'pgr_pushRelabel(One to One)
- Directed graph
- Parameters:
  - Edges SQL with columns: id, source, target, capacity [,reverse_capacity]
  - From vertex identifier
  - To vertex identifier
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_pushRelabel.html
';

alter function pgr_pushrelabel(text, bigint, bigint, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) owner to postgres;

