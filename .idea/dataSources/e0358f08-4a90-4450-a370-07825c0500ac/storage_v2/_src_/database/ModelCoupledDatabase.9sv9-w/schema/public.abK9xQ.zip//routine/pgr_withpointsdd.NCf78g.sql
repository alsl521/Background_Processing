create function pgr_withpointsdd(text, text, anyarray, double precision, character, directed boolean DEFAULT true, details boolean DEFAULT false, equicost boolean DEFAULT false, OUT seq bigint, OUT depth bigint, OUT start_vid bigint, OUT pred bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, depth, start_vid, pred, node, edge, cost, agg_cost
    FROM _pgr_withPointsDDv4(_pgr_get_statement($1), _pgr_get_statement($2), $3, $4, $5, $6, $7, $8);
$$;

comment on function pgr_withpointsdd(text, text, anyarray, double precision, char, boolean, boolean, boolean, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_withPointsDD(Multiple Vertices)
- PROPOSED
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - Points SQL with columns: [pid], edge_id, fraction[,side]
    - From ARRAY[vertices identifiers]
    - Distance
    - Driving_side
- Optional Parameters
    - directed := true
    - details := false
    - equicost := false
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_withPointsDD.html
';

alter function pgr_withpointsdd(text, text, anyarray, double precision, char, boolean, boolean, boolean, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

