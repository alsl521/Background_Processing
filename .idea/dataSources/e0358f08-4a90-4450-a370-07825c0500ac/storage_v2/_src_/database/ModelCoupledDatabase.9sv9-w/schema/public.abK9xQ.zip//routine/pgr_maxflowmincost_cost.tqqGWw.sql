create function pgr_maxflowmincost_cost(text, text) returns double precision
    strict
    language sql
as
$$
    SELECT cost
    FROM _pgr_maxFlowMinCost(_pgr_get_statement($1), _pgr_get_statement($2), only_cost := true);
$$;

comment on function pgr_maxflowmincost_cost(text, text) is 'EXPERIMENTAL pgr_maxFlowMinCost_Cost (Combinations)
- EXPERIMENTAL
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
  - Combinations SQL with columns: source, target
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_maxFlowMinCost_Cost.html
';

alter function pgr_maxflowmincost_cost(text, text) owner to postgres;

