create function pgr_withpointsksp(text, text, bigint, bigint, integer, directed boolean DEFAULT true, heap_paths boolean DEFAULT false, driving_side character DEFAULT 'b'::bpchar, details boolean DEFAULT false, OUT seq integer, OUT path_id integer, OUT path_seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
    RAISE WARNING 'pgr_withPointsKSP(text,text,bigint,bigint,integer,boolean,boolean,char,boolean) deprecated signature on v3.6.0';
    RETURN QUERY
    SELECT a.seq, a.path_id, a.path_seq, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_withPointsKSP(_pgr_get_statement($1), _pgr_get_statement($2), $3, $4, $5, $6, $7, $8, $9) AS a;
END
$$;

comment on function pgr_withpointsksp(text, text, bigint, bigint, integer, boolean, boolean, char, boolean, out integer, out integer, out integer, out bigint, out bigint, out double precision, out double precision) is 'pgr_withPointsKSP deprecated signature on v3.6.0
- Documentation: https://docs.pgrouting.org/latest/en/pgr_withPointsKSP.html';

alter function pgr_withpointsksp(text, text, bigint, bigint, integer, boolean, boolean, char, boolean, out integer, out integer, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

