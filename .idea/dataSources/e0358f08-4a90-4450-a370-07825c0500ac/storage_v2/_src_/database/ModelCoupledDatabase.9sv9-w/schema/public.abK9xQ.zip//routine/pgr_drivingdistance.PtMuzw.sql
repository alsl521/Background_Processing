create function pgr_drivingdistance(text, anyarray, double precision, directed boolean DEFAULT true, equicost boolean DEFAULT false, OUT seq bigint, OUT depth bigint, OUT start_vid bigint, OUT pred bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, depth, start_vid, pred, node, edge, cost, agg_cost
    FROM _pgr_drivingDistancev4(_pgr_get_statement($1), $2, $3, $4, $5);
$$;

comment on function pgr_drivingdistance(text, anyarray, double precision, boolean, boolean, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_drivingDistance(Multiple vertices)
- Parameters:
   - Edges SQL with columns: id, source, target, cost [,reverse_cost]
   - From ARRAY[vertices identifiers]
   - Distance from vertices identifiers
- Optional Parameters
   - directed := true
   - equicost := false
- Documentation:
   - https://docs.pgrouting.org/latest/en/pgr_drivingDistance.html
';

alter function pgr_drivingdistance(text, anyarray, double precision, boolean, boolean, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

