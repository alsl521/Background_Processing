create function pgr_bdastar(text, bigint, anyarray, directed boolean DEFAULT true, heuristic integer DEFAULT 5, factor numeric DEFAULT 1.0, epsilon numeric DEFAULT 1.0, OUT seq integer, OUT path_seq integer, OUT start_vid bigint, OUT end_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, path_seq, start_vid, end_vid, node, edge, cost, agg_cost
    FROM _pgr_bdAstar(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], $4, $5, $6::FLOAT, $7::FLOAT, false);
$$;

comment on function pgr_bdastar(text, bigint, anyarray, boolean, integer, numeric, numeric, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_bdAstar(One to Many)
- Parameters:
  - edges SQL with columns: id, source, target, cost [,reverse_cost], x1, y1, x2, y2
  - From vertex identifier
  - To ARRAY[vertices identifiers]
- Optional Parameters:
  - directed := true
  - heuristic := 5
  - factor := 1
  - epsilon := 1
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_bdAstar.html
';

alter function pgr_bdastar(text, bigint, anyarray, boolean, integer, numeric, numeric, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

