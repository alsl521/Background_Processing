create function geometry(pcpatch) returns geometry
    language sql
as
$$
		SELECT public.PC_EnvelopeGeometry($1)
	$$;

alter function geometry(pcpatch) owner to postgres;

