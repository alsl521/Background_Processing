create function _pgr_getcolumntype(tab text, col text, reporterrs integer DEFAULT 0, fnname text DEFAULT '_pgr_getColumnType'::text) returns text
    strict
    language plpgsql
as
$$
DECLARE
    sname text;
    tname text;
    cname text;
    ctype text;
    naming record;
    err boolean;
BEGIN

    select * into naming from _pgr_getTableName(tab,reportErrs, fnName) ;
    sname=naming.sname;
    tname=naming.tname;
    select _pgr_getColumnName into cname from _pgr_getColumnName(tab,col,reportErrs, fnName) ;
    select _pgr_getColumnType into ctype from _pgr_getColumnType(sname,tname,cname,reportErrs, fnName);
    RETURN ctype;
END;

$$;

comment on function _pgr_getcolumntype(text, text, integer, text) is 'pgRouting internal function';

alter function _pgr_getcolumntype(text, text, integer, text) owner to postgres;

