create function pgr_maxflowmincost(text, anyarray, anyarray, OUT seq integer, OUT edge bigint, OUT source bigint, OUT target bigint, OUT flow bigint, OUT residual_capacity bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, edge, source, target, flow, residual_capacity, cost, agg_cost
    FROM _pgr_maxFlowMinCost(_pgr_get_statement($1), $2::BIGINT[], $3::BIGINT[], only_cost := false);
$$;

comment on function pgr_maxflowmincost(text, anyarray, anyarray, out integer, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'EXPERIMENTAL pgr_maxFlowMinCost(Many to Many)
- EXPERIMENTAL
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
  - From ARRAY[vertices identifiers]
  - To ARRAY[vertices identifiers]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_maxFlowMinCost.html
';

alter function pgr_maxflowmincost(text, anyarray, anyarray, out integer, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

