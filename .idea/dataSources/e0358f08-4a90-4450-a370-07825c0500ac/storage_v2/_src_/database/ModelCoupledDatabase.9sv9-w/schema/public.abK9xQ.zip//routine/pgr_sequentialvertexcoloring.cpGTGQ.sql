create function pgr_sequentialvertexcoloring(text, OUT vertex_id bigint, OUT color_id bigint) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT a.vertex_id, a.color_id
    FROM _pgr_sequentialVertexColoring(_pgr_get_statement($1)) AS a;
END;
$$;

comment on function pgr_sequentialvertexcoloring(text, out bigint, out bigint) is 'pgr_sequentialVertexColoring
- PROPOSED
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_sequentialVertexColoring.html
';

alter function pgr_sequentialvertexcoloring(text, out bigint, out bigint) owner to postgres;

