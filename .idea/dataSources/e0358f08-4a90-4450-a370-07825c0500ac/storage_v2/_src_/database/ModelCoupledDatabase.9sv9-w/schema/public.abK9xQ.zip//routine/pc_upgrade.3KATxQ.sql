create function pc_upgrade(to_version text DEFAULT NULL::text) returns text
    language plpgsql
as
$$
DECLARE
	ver RECORD;
	target_version text;
BEGIN
	SELECT default_version, installed_version
	FROM pg_catalog.pg_available_extensions
	WHERE name = 'pointcloud'
	INTO ver;

	IF to_version IS NULL THEN
		target_version := ver.default_version;
	ELSE
		target_version := to_version;
	END IF;

	IF target_version != ver.installed_version THEN
		EXECUTE 'ALTER EXTENSION pointcloud UPDATE TO ' ||
			quote_literal(target_version);
	ELSE
		-- Use the "next" trick
		IF target_version LIKE '%next' THEN
			target_version := replace(target_version, 'next', '');
			EXECUTE 'ALTER EXTENSION pointcloud UPDATE TO ' ||
				quote_literal(target_version);
		ELSE
			-- Double upgrade, to get back to "next"-free
			EXECUTE 'ALTER EXTENSION pointcloud UPDATE TO ' ||
				quote_literal(target_version || 'next');
			EXECUTE 'ALTER EXTENSION pointcloud UPDATE TO ' ||
				quote_literal(target_version);
		END IF;
	END IF;

	RETURN public.pc_version();
END;
$$;

alter function pc_upgrade(text) owner to postgres;

