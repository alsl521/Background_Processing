create function pgr_topologicalsort(text, OUT seq integer, OUT sorted_v bigint) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, sorted_v
    FROM _pgr_topologicalSort(_pgr_get_statement($1));
$$;

comment on function pgr_topologicalsort(text, out integer, out bigint) is 'pgr_topologicalSort
- EXPERIMENTAL
- Directed graph
- Parameters:
  - edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_topologicalSort.html
';

alter function pgr_topologicalsort(text, out integer, out bigint) owner to postgres;

