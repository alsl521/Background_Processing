create function _pgr_startpoint(g geometry) returns geometry
    immutable
    language sql
as
$$
SELECT CASE WHEN geometryType($1) ~ '^MULTI' THEN ST_StartPoint(ST_geometryN($1,1))
ELSE ST_StartPoint($1)
END;
$$;

comment on function _pgr_startpoint(geometry) is 'pgRouting internal function';

alter function _pgr_startpoint(geometry) owner to postgres;

