create function pgr_kruskalbfs(text, bigint, max_depth bigint DEFAULT '9223372036854775807'::bigint, OUT seq bigint, OUT depth bigint, OUT start_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
    IF $3 < 0 THEN
        RAISE EXCEPTION 'Negative value found on ''max_depth'''
        USING HINT = format('Value found: %s', $3);
    END IF;


    RETURN QUERY
    SELECT a.seq, a.depth, a.start_vid, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_kruskal(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], 'BFS', $3, -1) AS a;
END;
$$;

comment on function pgr_kruskalbfs(text, bigint, bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_kruskalBFS(Single Vertex)
- Undirected graph
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - From root vertex identifier
- Optional parameters
    - max_depth: default := 9223372036854775807
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_kruskalBFS.html
';

alter function pgr_kruskalbfs(text, bigint, bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

