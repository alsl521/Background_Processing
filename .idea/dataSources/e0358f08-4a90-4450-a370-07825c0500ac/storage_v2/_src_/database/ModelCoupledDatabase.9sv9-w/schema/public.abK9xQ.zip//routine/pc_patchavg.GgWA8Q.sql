create function pc_patchavg(p pcpatch) returns pcpoint
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT _PC_PatchStat(p, 2) $$;

alter function pc_patchavg(pcpatch) owner to postgres;

