create function pgr_pickdeliver(text, text, text, factor double precision DEFAULT 1, max_cycles integer DEFAULT 10, initial_sol integer DEFAULT 4, OUT seq integer, OUT vehicle_seq integer, OUT vehicle_id bigint, OUT stop_seq integer, OUT stop_type integer, OUT stop_id bigint, OUT order_id bigint, OUT cargo double precision, OUT travel_time double precision, OUT arrival_time double precision, OUT wait_time double precision, OUT service_time double precision, OUT departure_time double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, vehicle_seq, vehicle_id, stop_seq, stop_type, stop_id, order_id, cargo, travel_time, arrival_time,
           wait_time, service_time, departure_time
    FROM _pgr_pickDeliver(_pgr_get_statement($1), _pgr_get_statement($2), $3, $4, $5);
$$;

comment on function pgr_pickdeliver(text, text, text, double precision, integer, integer, out integer, out integer, out bigint, out integer, out integer, out bigint, out bigint, out double precision, out double precision, out double precision, out double precision, out double precision, out double precision) is 'pgr_pickDeliver
 - EXPERIMENTAL
 - Parameters:
   - orders SQL with columns:
     - id, demand, p_node_id, p_open, p_close, d_node_id, d_open, d_close
     - optional columns:
        - p_service := 0
        - d_service := 0
   - vehicles SQL with columns:
     - id, capacity, start_open, start_close
     - optional columns:
        - speed := 1
        - start_service := 0
        - end_open := start_open
        - end_close := start_close
        - end_service := 0
   - Matrix
     - start_vid
     - end_vid
     - agg_cost
 - Optional Parameters:
   - factor: default := 1
   - max_cycles: default := 10
   - initial_sol: default := 4
- Documentation:
   - https://docs.pgrouting.org/latest/en/pgr_pickDeliver.html
';

alter function pgr_pickdeliver(text, text, text, double precision, integer, integer, out integer, out integer, out bigint, out integer, out integer, out bigint, out bigint, out double precision, out double precision, out double precision, out double precision, out double precision, out double precision) owner to postgres;

