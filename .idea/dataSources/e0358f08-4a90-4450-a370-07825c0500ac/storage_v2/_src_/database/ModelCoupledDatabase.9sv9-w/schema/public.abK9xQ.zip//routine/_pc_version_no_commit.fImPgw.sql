create function _pc_version_no_commit(libver text, scrver text) returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
	libver_no_commit TEXT;
BEGIN
	libver_no_commit := split_part(libver, ' ', 1);
	IF scrver != libver_no_commit THEN
		RAISE WARNING 'Library (%) and script (%) version mismatch',
			libver_no_commit, scrver;
	END IF;
	RETURN libver_no_commit;
END;
$$;

alter function _pc_version_no_commit(text, text) owner to postgres;

