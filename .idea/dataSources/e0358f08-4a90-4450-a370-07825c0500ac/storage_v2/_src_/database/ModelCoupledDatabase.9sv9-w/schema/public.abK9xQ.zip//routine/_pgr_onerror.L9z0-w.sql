create function _pgr_onerror(errcond boolean, reporterrs integer, fnname text, msgerr text, hinto text DEFAULT 'No hint'::text, msgok text DEFAULT 'OK'::text) returns void
    strict
    language plpgsql
as
$$
BEGIN
  if errCond=true then
     if reportErrs=0 then
       raise debug '----> PGR DEBUG in %: %',fnName,msgerr USING HINT = '  ---->'|| hinto;
     else
       if reportErrs = 2 then
         raise notice '----> PGR ERROR in %: %',fnName,msgerr USING HINT = '  ---->'|| hinto;
         raise raise_exception;
       else
         raise notice '----> PGR NOTICE in %: %',fnName,msgerr USING HINT = '  ---->'|| hinto;
       end if;
     end if;
  else
       raise debug 'PGR ----> %: %',fnName,msgok;
  end if;
END;
$$;

comment on function _pgr_onerror(boolean, integer, text, text, text, text) is 'pgRouting internal function';

alter function _pgr_onerror(boolean, integer, text, text, text, text) owner to postgres;

