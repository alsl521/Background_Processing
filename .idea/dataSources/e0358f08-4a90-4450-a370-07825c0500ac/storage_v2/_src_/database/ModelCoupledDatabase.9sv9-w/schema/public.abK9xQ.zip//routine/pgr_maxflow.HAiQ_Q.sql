create function pgr_maxflow(text, anyarray, bigint) returns bigint
    strict
    language sql
as
$$
        SELECT flow
        FROM _pgr_maxflow(_pgr_get_statement($1), $2::BIGINT[], ARRAY[$3]::BIGINT[], algorithm := 1, only_flow := true);
  $$;

comment on function pgr_maxflow(text, anyarray, bigint) is 'pgr_maxFlow(Many to One)
- Directed graph
- Parameters:
  - edges SQL with columns: id, source, target, capacity [,reverse_capacity]
  - from ARRAY[vertices identifiers]
  - to vertex
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_maxFlow.html
';

alter function pgr_maxflow(text, anyarray, bigint) owner to postgres;

