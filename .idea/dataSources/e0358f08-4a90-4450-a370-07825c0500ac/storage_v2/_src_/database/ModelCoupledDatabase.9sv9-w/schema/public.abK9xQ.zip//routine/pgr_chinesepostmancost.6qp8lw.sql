create function pgr_chinesepostmancost(text) returns double precision
    strict
    language sql
as
$$
    SELECT cost
    FROM _pgr_chinesePostman(_pgr_get_statement($1), only_cost := true);
$$;

comment on function pgr_chinesepostmancost(text) is 'pgr_chinesePostmanCost
- EXPERIMENTAL
- Directed graph
- Parameters:
	- Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
	- https://docs.pgrouting.org/latest/en/pgr_chinesePostmanCost.html
';

alter function pgr_chinesepostmancost(text) owner to postgres;

