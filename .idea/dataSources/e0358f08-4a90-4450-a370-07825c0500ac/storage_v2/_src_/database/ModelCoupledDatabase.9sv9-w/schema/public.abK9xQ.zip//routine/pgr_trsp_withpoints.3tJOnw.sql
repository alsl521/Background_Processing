create function pgr_trsp_withpoints(text, text, text, text, directed boolean DEFAULT true, driving_side character DEFAULT 'r'::bpchar, details boolean DEFAULT false, OUT seq integer, OUT path_seq integer, OUT start_vid bigint, OUT end_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT seq, path_seq, departure, end_vid, node, edge, cost, agg_cost
FROM _pgr_trsp_withPoints(
  _pgr_get_statement($1),
  _pgr_get_statement($2),
  _pgr_get_statement($3),
  _pgr_get_statement($4),
  $5, $6, $7);
$$;

comment on function pgr_trsp_withpoints(text, text, text, text, boolean, char, boolean, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_trsp_withPoints(Combinations)
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
  - Restrictions SQL with columns: id, path, cost
  - Points SQL with columns: [pid], edge_id, fraction [,side]
  - Combinations SQL with columns: source, target
- Optional Parameters:
  - directed := ''true''
  - driving_side := ''r''
  - details := ''false''
- Documentation:
- https://docs.pgrouting.org/latest/en/pgr_trsp_withPoints.html
';

alter function pgr_trsp_withpoints(text, text, text, text, boolean, char, boolean, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

