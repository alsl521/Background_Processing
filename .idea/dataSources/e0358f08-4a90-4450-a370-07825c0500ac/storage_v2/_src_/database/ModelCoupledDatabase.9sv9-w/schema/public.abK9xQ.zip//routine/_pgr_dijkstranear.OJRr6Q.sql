create function _pgr_dijkstranear(text, anyarray, bigint, bigint, directed boolean DEFAULT true, OUT seq integer, OUT path_seq integer, OUT start_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    language sql
as
$$
    SELECT seq, path_seq, start_vid, node, edge, cost, agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), $2::BIGINT[], ARRAY[$3]::BIGINT[], $5, false, false, $4);
$$;

comment on function _pgr_dijkstranear(text, anyarray, bigint, bigint, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgRouting internal function';

alter function _pgr_dijkstranear(text, anyarray, bigint, bigint, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

