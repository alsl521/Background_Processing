create function _v4trsp(text, text, text, directed boolean DEFAULT true, OUT seq integer, OUT path_seq integer, OUT start_vid bigint, OUT end_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
  SELECT seq, path_seq, start_vid, end_vid, node, edge, cost, agg_cost
  FROM _pgr_trspv4( $1, $2, $3, $4);
$$;

comment on function _v4trsp(text, text, text, boolean, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgRouting internal function deprecated on v3.6.0';

alter function _v4trsp(text, text, text, boolean, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

