create function pgr_pushrelabel(text, anyarray, bigint, OUT seq integer, OUT edge bigint, OUT start_vid bigint, OUT end_vid bigint, OUT flow bigint, OUT residual_capacity bigint) returns SETOF record
    strict
    language sql
as
$$
        SELECT seq, edge_id, source, target, flow, residual_capacity
        FROM _pgr_maxflow(_pgr_get_statement($1), $2::BIGINT[], ARRAY[$3]::BIGINT[], 1);
  $$;

comment on function pgr_pushrelabel(text, anyarray, bigint, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) is 'pgr_pushRelabel(Many to One)
- Directed graph
- Parameters:
  - Edges SQL with columns: id, source, target, capacity [,reverse_capacity]
  - From ARRAY[vertices identifiers]
  - To vertex identifie
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_pushRelabel.html
';

alter function pgr_pushrelabel(text, anyarray, bigint, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) owner to postgres;

