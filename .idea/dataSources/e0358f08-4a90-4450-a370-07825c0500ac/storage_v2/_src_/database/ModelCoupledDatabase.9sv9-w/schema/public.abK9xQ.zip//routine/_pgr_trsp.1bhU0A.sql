create function _pgr_trsp(text, text, anyarray, anyarray, directed boolean DEFAULT true, OUT seq integer, OUT path_seq integer, OUT start_vid bigint, OUT end_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT a.seq, a.path_seq, a.start_vid, a.end_vid, a.node, a.edge, a.cost, a.agg_cost
        FROM _trsp(
            _pgr_get_statement($1),
            _pgr_get_statement($2),
            $3::bigint[],
            $4::bigint[],
            $5) AS a;
$$;

comment on function _pgr_trsp(text, text, anyarray, anyarray, boolean, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgRouting internal function deprecated on v3.4.0';

alter function _pgr_trsp(text, text, anyarray, anyarray, boolean, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

