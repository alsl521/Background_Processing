create function pgr_cuthillmckeeordering(text, OUT seq bigint, OUT node bigint) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, node
    FROM _pgr_cuthillMckeeOrdering(_pgr_get_statement($1));
$$;

comment on function pgr_cuthillmckeeordering(text, out bigint, out bigint) is 'pgr_cuthillMckeeOrdering
- EXPERIMENTAL
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_cuthillMckeeOrdering.html
';

alter function pgr_cuthillmckeeordering(text, out bigint, out bigint) owner to postgres;

