create function pgr_kruskal(text, OUT edge bigint, OUT cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT edge, cost
    FROM _pgr_kruskal(_pgr_get_statement($1), ARRAY[0]::BIGINT[], '', -1, -1);
$$;

comment on function pgr_kruskal(text, out bigint, out double precision) is 'pgr_kruskal
- Undirected graph
- Parameters:
	- Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
	- https://docs.pgrouting.org/latest/en/pgr_kruskal.html
';

alter function pgr_kruskal(text, out bigint, out double precision) owner to postgres;

