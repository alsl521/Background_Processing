create function pgr_maxflowmincost_cost(text, anyarray, anyarray) returns double precision
    strict
    language sql
as
$$
    SELECT cost
    FROM _pgr_maxFlowMinCost(_pgr_get_statement($1), $2::BIGINT[], $3::BIGINT[], only_cost := true);
$$;

comment on function pgr_maxflowmincost_cost(text, anyarray, anyarray) is 'EXPERIMENTAL pgr_maxFlowMinCost_Cost (Many to Many)
- EXPERIMENTAL
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
  - From ARRAY[vertices identifiers]
  - To ARRAY[vertices identifiers]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_maxFlowMinCost_Cost.html
';

alter function pgr_maxflowmincost_cost(text, anyarray, anyarray) owner to postgres;

