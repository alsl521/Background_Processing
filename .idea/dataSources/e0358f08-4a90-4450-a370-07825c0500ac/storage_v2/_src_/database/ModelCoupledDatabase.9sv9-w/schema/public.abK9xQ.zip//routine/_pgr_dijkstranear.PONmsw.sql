create function _pgr_dijkstranear(text, bigint, anyarray, bigint, directed boolean DEFAULT true, OUT seq integer, OUT path_seq integer, OUT end_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    language sql
as
$$
    SELECT seq, path_seq, end_vid, node, edge, cost, agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], $5, false, true, $4);
$$;

comment on function _pgr_dijkstranear(text, bigint, anyarray, bigint, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgRouting internal function';

alter function _pgr_dijkstranear(text, bigint, anyarray, bigint, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

