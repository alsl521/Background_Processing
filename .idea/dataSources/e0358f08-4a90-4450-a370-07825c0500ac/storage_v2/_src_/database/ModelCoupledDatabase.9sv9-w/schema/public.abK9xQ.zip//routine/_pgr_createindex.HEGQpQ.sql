create function _pgr_createindex(tabname text, colname text, indext text, reporterrs integer DEFAULT 1, fnname text DEFAULT '_pgr_createIndex'::text) returns void
    strict
    language plpgsql
as
$$
DECLARE
    naming record;
    sname text;
    tname text;

BEGIN
    select * from _pgr_getTableName(tabname, 2, fnName)  into naming;
    sname=naming.sname;
    tname=naming.tname;
    execute _pgr_createIndex(sname, tname, colname, indext, reportErrs, fnName);
END;

$$;

comment on function _pgr_createindex(text, text, text, integer, text) is 'pgRouting internal function';

alter function _pgr_createindex(text, text, text, integer, text) owner to postgres;

