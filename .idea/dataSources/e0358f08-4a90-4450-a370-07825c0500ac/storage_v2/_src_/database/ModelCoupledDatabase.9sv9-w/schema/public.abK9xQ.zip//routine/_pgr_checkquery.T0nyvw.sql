create function _pgr_checkquery(text) returns text
    strict
    language plpgsql
as
$fun$
DECLARE
  main_sql TEXT;

BEGIN

  BEGIN
    EXECUTE format($$
      SELECT regexp_replace(regexp_replace(statement, %1$L,'','i'),';$','')
      FROM pg_prepared_statements WHERE name = %2$L$$,
      '.*' || $1 || '\s*as', $1)
    INTO main_sql;

    EXCEPTION WHEN OTHERS
      THEN main_sql := $1;
  END;

  IF main_sql IS NULL THEN
    main_sql := $1;
  END IF;

  BEGIN
    EXECUTE format('SELECT * FROM ( %1$s ) AS __a__ limit 1', main_sql);

    EXCEPTION WHEN OTHERS THEN
      RAISE EXCEPTION '%', SQLERRM
      USING HINT = 'Please check query: '|| $1;
  END;

  RETURN main_sql;

END;
$fun$;

comment on function _pgr_checkquery(text) is 'pgrouting internal function';

alter function _pgr_checkquery(text) owner to postgres;

