create function pgr_contraction(text, bigint[], max_cycles integer DEFAULT 1, forbidden_vertices bigint[] DEFAULT ARRAY[]::bigint[], directed boolean DEFAULT true, OUT type text, OUT id bigint, OUT contracted_vertices bigint[], OUT source bigint, OUT target bigint, OUT cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT type, id, contracted_vertices, source, target, cost
    FROM _pgr_contraction(_pgr_get_statement($1), $2::BIGINT[],  $3, $4, $5);
$$;

comment on function pgr_contraction(text, bigint[], integer, bigint[], boolean, out text, out bigint, out bigint[], out bigint, out bigint, out double precision) is 'pgr_contraction
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - ARRAY [Contraction order]
- Optional Parameters
    - max_cycles := 1
    - forbidden_vertices := ARRAY[]::BIGINT[]
    - directed := true
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_contraction.html
';

alter function pgr_contraction(text, bigint[], integer, bigint[], boolean, out text, out bigint, out bigint[], out bigint, out bigint, out double precision) owner to postgres;

