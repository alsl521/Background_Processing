create function geometry(pcpoint) returns geometry
    language sql
as
$$
		SELECT public.ST_GeomFromEWKB(public.PC_AsBinary($1))
	$$;

alter function geometry(pcpoint) owner to postgres;

