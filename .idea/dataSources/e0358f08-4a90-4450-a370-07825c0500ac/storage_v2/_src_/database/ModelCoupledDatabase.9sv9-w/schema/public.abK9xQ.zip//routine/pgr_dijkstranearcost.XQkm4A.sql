create function pgr_dijkstranearcost(text, text, directed boolean DEFAULT true, cap bigint DEFAULT 1, global boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT start_vid, end_vid, agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), _pgr_get_statement($2), directed, true, cap, global);
$$;

comment on function pgr_dijkstranearcost(text, text, boolean, bigint, boolean, out bigint, out bigint, out double precision) is 'pgr_dijkstraNearCost(Combinations)
- PROPOSED
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
  - Combinations SQL with columns: source, target
- Optional Parameters
  - directed => true
  - cap => 1 (nth found)
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_dijkstraNearCost.html
';

alter function pgr_dijkstranearcost(text, text, boolean, bigint, boolean, out bigint, out bigint, out double precision) owner to postgres;

