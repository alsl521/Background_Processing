create function pc_envelopegeometry(pcpatch) returns geometry
    language sql
as
$$
		SELECT public.ST_GeomFromEWKB(public.PC_EnvelopeAsBinary($1))
	$$;

alter function pc_envelopegeometry(pcpatch) owner to postgres;

