create function pgr_maxflowmincost_cost(text, bigint, bigint) returns double precision
    strict
    language sql
as
$$
    SELECT cost
    FROM _pgr_maxFlowMinCost(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], ARRAY[$3]::BIGINT[], only_cost := true);
$$;

comment on function pgr_maxflowmincost_cost(text, bigint, bigint) is 'pgr_maxFlowMinCost_Cost (One to One)
- EXPERIMENTAL
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
  - From vertex identifier
  - To vertex identifier
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_maxFlowMinCost_Cost.html
';

alter function pgr_maxflowmincost_cost(text, bigint, bigint) owner to postgres;

