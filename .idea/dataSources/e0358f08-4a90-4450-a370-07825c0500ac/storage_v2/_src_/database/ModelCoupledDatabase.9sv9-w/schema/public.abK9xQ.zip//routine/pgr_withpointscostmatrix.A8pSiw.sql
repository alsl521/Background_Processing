create function pgr_withpointscostmatrix(text, text, anyarray, directed boolean DEFAULT true, driving_side character DEFAULT 'b'::bpchar, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT a.start_pid, a.end_pid, a.agg_cost
    FROM _pgr_withPoints(_pgr_get_statement($1), _pgr_get_statement($2), $3, $3, $4,  $5, TRUE, TRUE) AS a;
$$;

comment on function pgr_withpointscostmatrix(text, text, anyarray, boolean, char, out bigint, out bigint, out double precision) is 'pgr_withPointsCostMatrix
- PROPOSED
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - Points SQL with columns: [pid], edge_id, fraction[,side]
    - ARRAY [points identifiers],
- Optional Parameters
    - directed := true
    - driving_side := ''b''
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_withPointsCostMatrix.html
';

alter function pgr_withpointscostmatrix(text, text, anyarray, boolean, char, out bigint, out bigint, out double precision) owner to postgres;

