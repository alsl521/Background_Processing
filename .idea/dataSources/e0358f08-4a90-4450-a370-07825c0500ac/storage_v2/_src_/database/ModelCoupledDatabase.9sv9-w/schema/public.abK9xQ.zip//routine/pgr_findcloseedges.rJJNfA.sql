create function pgr_findcloseedges(text, geometry[], double precision, cap integer DEFAULT 1, partial boolean DEFAULT true, dryrun boolean DEFAULT false, OUT edge_id bigint, OUT fraction double precision, OUT side character, OUT distance double precision, OUT geom geometry, OUT edge geometry) returns SETOF record
    strict
    cost 5
    language plpgsql
as
$$
DECLARE
  edges_SQL TEXT;
  has_id BOOLEAN;
  has_geom BOOLEAN;
  ret_query TEXT;
  ret_query_end TEXT;
BEGIN

  IF ($3 < 0) THEN
    RAISE EXCEPTION 'Invalid value for tolerance';
  END IF;

  edges_sql := _pgr_checkQuery($1);
  has_id := _pgr_checkColumn(edges_sql, 'id', 'ANY-INTEGER', false, dryrun => dryrun);
  has_geom := _pgr_checkColumn(edges_sql, 'geom', 'geometry', false, dryrun => dryrun);

  ret_query = format(
    $q$
WITH
edges_sql AS (%1$s),
point_sql AS (SELECT unnest(%2$L::geometry[]) AS point),
results AS (
  SELECT
    id::BIGINT AS edge_id,
    ST_LineLocatePoint(geom, point) AS fraction,
    CASE WHEN ST_Intersects(ST_Buffer(geom, %3$s, 'side=right endcap=flat'), point)
         THEN 'r'
         ELSE 'l' END::CHAR AS side,
    geom <-> point AS distance,
    point,
    $q$, edges_sql, $2, $3);

  ret_query_end = format(
    $q$
  FROM  edges_sql, point_sql
  WHERE ST_DWithin(geom, point, %1$s)
  ORDER BY geom <-> point),
prepare_cap AS (
  SELECT row_number() OVER (PARTITION BY point ORDER BY point, distance) AS rn, *
  FROM results)
SELECT edge_id, fraction, side, distance, point, new_line
FROM prepare_cap
WHERE rn <= %2$s
    $q$, $3, cap);

  IF partial AND NOT dryrun THEN

    ret_query = ret_query
      || $q$NULL::geometry AS new_line$q$
      || ret_query_end;

  ELSE

    ret_query = ret_query
      || $q$ST_MakeLine(point, ST_ClosestPoint(geom, point)) AS new_line $q$
      || ret_query_end;

  END IF;

  IF dryrun THEN
    RAISE NOTICE '%', ret_query;
    RETURN;
  END IF;

  RETURN query EXECUTE ret_query;

END;
$$;

alter function pgr_findcloseedges(text, geometry[], double precision, integer, boolean, boolean, out bigint, out double precision, out char, out double precision, out geometry, out geometry) owner to postgres;

