create function pgr_bdastarcost(text, bigint, bigint, directed boolean DEFAULT true, heuristic integer DEFAULT 5, factor numeric DEFAULT 1.0, epsilon numeric DEFAULT 1.0, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT a.start_vid, a.end_vid, a.agg_cost
    FROM _pgr_bdAstar(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], ARRAY[$3]::BIGINT[], $4, $5, $6::FLOAT, $7::FLOAT, true) AS a;
$$;

comment on function pgr_bdastarcost(text, bigint, bigint, boolean, integer, numeric, numeric, out bigint, out bigint, out double precision) is 'pgr_bdAstarCost(One to One)
- Parameters:
  - edges SQL with columns: id, source, target, cost [,reverse_cost], x1, y1, x2, y2
  - From vertex identifier
  - To vertex identifier
- Optional Parameters:
  - directed := true
  - heuristic := 5
  - factor := 1
  - epsilon := 1
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_bdAstarCost.html
';

alter function pgr_bdastarcost(text, bigint, bigint, boolean, integer, numeric, numeric, out bigint, out bigint, out double precision) owner to postgres;

