create function pgr_transitiveclosure(text, OUT seq integer, OUT vid bigint, OUT target_array bigint[]) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, vid, target_array
    FROM _pgr_transitiveClosure(_pgr_get_statement($1));
$$;

comment on function pgr_transitiveclosure(text, out integer, out bigint, out bigint[]) is 'pgr_transitiveClosure
- EXPERIMENTAL
- Directed graph
- Parameters:
  - edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_transitiveClosure.html
';

alter function pgr_transitiveclosure(text, out integer, out bigint, out bigint[]) owner to postgres;

