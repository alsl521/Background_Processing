create function pgr_linegraph(text, directed boolean DEFAULT true, OUT seq integer, OUT source bigint, OUT target bigint, OUT cost double precision, OUT reverse_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, source, target, cost, reverse_cost
    FROM _pgr_lineGraph(_pgr_get_statement($1), $2)
$$;

comment on function pgr_linegraph(text, boolean, out integer, out bigint, out bigint, out double precision, out double precision) is 'pgr_lineGraph
- EXPERIMENTAL
- Parameters:
  - edges SQL with columns: id, source, target, cost [,reverse_cost]
- Optional Parameters:
  - directed := true
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_lineGraph.html
';

alter function pgr_linegraph(text, boolean, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

