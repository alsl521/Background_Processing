create function pgr_linegraphfull(text, OUT seq integer, OUT source bigint, OUT target bigint, OUT cost double precision, OUT edge bigint) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, source, target, cost, edge
    FROM _pgr_lineGraphFull(_pgr_get_statement($1))
$$;

comment on function pgr_linegraphfull(text, out integer, out bigint, out bigint, out double precision, out bigint) is 'pgr_lineGraphFull
- EXPERIMENTAL
- For Directed Graph
- Parameters:
  - edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_lineGraphFull.html
';

alter function pgr_linegraphfull(text, out integer, out bigint, out bigint, out double precision, out bigint) owner to postgres;

