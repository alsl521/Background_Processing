create function pc_patchmax(p pcpatch, attr text) returns numeric
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT _PC_PatchStat(p, 1, attr) $$;

alter function pc_patchmax(pcpatch, text) owner to postgres;

