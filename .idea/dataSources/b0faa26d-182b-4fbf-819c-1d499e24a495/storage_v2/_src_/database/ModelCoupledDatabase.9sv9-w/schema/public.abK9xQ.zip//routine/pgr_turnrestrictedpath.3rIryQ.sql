create function pgr_turnrestrictedpath(text, text, bigint, bigint, integer, directed boolean DEFAULT true, heap_paths boolean DEFAULT false, stop_on_first boolean DEFAULT true, strict boolean DEFAULT false, OUT seq integer, OUT path_id integer, OUT path_seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, path_id, path_seq, node, edge, cost, agg_cost
    FROM _pgr_turnRestrictedPath(_pgr_get_statement($1), _pgr_get_statement($2), $3, $4, $5, $6, $7, $8, $9);
$$;

comment on function pgr_turnrestrictedpath(text, text, bigint, bigint, integer, boolean, boolean, boolean, boolean, out integer, out integer, out integer, out bigint, out bigint, out double precision, out double precision) is 'pgr_turnRestrictedPath
- EXPERIMENTAL
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - Restrictions SQL with columns: id, cost, path
    - From vertex identifier
    - To vertex identifier
    - K
- Optional Parameters
    - directed := true
    - heap paths := false
    - stop on first := true
    - strict := false
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_turnRestrictedPath.html
';

alter function pgr_turnrestrictedpath(text, text, bigint, bigint, integer, boolean, boolean, boolean, boolean, out integer, out integer, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

