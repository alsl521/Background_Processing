create function pc_patchmax(p pcpatch) returns pcpoint
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT _PC_PatchStat(p, 1) $$;

alter function pc_patchmax(pcpatch) owner to postgres;

