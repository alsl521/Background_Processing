create function pgr_bridges(text, OUT edge bigint) returns SETOF bigint
    strict
    language sql
as
$$
    SELECT edge
    FROM _pgr_bridges(_pgr_get_statement($1));
$$;

comment on function pgr_bridges(text, out bigint) is 'pgr_bridges
- Undirected graph
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_bridges.html
';

alter function pgr_bridges(text, out bigint) owner to postgres;

