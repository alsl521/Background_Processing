create function pgr_makeconnected(text, OUT seq bigint, OUT start_vid bigint, OUT end_vid bigint) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, start_vid, end_vid
    FROM _pgr_makeConnected(_pgr_get_statement($1));
$$;

comment on function pgr_makeconnected(text, out bigint, out bigint, out bigint) is 'pgr_makeConnected
- EXPERIMENTAL
- Undirected graph
- Parameters:
  - edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_makeConnected.html
';

alter function pgr_makeconnected(text, out bigint, out bigint, out bigint) owner to postgres;

