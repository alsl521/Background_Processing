create function pc_patchmin(p pcpatch) returns pcpoint
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT _PC_PatchStat(p, 0) $$;

alter function pc_patchmin(pcpatch) owner to postgres;

