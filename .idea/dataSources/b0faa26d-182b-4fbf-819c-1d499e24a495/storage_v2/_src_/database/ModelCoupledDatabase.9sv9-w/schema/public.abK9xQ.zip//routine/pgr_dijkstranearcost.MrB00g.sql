create function pgr_dijkstranearcost(text, bigint, anyarray, directed boolean DEFAULT true, cap bigint DEFAULT 1, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT start_vid, end_vid, agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], directed, true, true, cap, true);
$$;

comment on function pgr_dijkstranearcost(text, bigint, anyarray, boolean, bigint, out bigint, out bigint, out double precision) is 'pgr_dijkstraNearCost(One to Many)
- PROPOSED
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
  - From vertex identifier
  - To ARRAY[vertices identifiers]
- Optional Parameters
  - directed => true
  - cap => 1 (nth found)
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_dijkstraNearCost.html
';

alter function pgr_dijkstranearcost(text, bigint, anyarray, boolean, bigint, out bigint, out bigint, out double precision) owner to postgres;

