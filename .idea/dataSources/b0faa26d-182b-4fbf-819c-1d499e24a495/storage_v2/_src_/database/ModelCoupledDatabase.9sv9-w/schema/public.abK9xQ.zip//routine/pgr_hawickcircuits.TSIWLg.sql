create function pgr_hawickcircuits(text, OUT seq integer, OUT path_id integer, OUT path_seq integer, OUT start_vid bigint, OUT end_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT a.seq, a.path_id, a.path_seq, a.start_vid, a.end_vid, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_hawickCircuits(_pgr_get_statement($1)) AS a;
END;
$$;

comment on function pgr_hawickcircuits(text, out integer, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_hawickCircuits
- EXPERIMENTAL
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_hawickCircuits.html
';

alter function pgr_hawickcircuits(text, out integer, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

