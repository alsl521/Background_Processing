create function pc_script_version() returns text
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT '1.2.4'::text $$;

alter function pc_script_version() owner to postgres;

