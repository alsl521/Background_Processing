create function pc_boundingdiagonalgeometry(pcpatch) returns geometry
    language sql
as
$$
		SELECT public.ST_GeomFromEWKB(public.PC_BoundingDiagonalAsBinary($1))
	$$;

alter function pc_boundingdiagonalgeometry(pcpatch) owner to postgres;

