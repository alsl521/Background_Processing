create function _pgr_iscolumnintable(tab text, col text) returns boolean
    strict
    language plpgsql
as
$$
DECLARE
    cname text;
BEGIN
    select _pgr_getColumnName from _pgr_getColumnName(tab,col,0, '_pgr_isColumnInTable') into cname;
    return cname is not null;
END;
$$;

comment on function _pgr_iscolumnintable(text, text) is 'pgRouting internal function';

alter function _pgr_iscolumnintable(text, text) owner to postgres;

