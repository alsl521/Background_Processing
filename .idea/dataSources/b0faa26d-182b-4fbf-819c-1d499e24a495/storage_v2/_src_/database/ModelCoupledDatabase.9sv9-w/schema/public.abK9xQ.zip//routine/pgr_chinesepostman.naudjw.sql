create function pgr_chinesepostman(text, OUT seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, node, edge, cost, agg_cost
    FROM _pgr_chinesePostman(_pgr_get_statement($1), only_cost := false);
$$;

comment on function pgr_chinesepostman(text, out integer, out bigint, out bigint, out double precision, out double precision) is 'pgr_chinesePostman
- EXPERIMENTAL
- Directed graph
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_chinesePostman.html
';

alter function pgr_chinesepostman(text, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

