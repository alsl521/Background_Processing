create function pgr_biconnectedcomponents(text, OUT seq bigint, OUT component bigint, OUT edge bigint) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, component, edge
    FROM _pgr_biconnectedComponents(_pgr_get_statement($1)) ;
$$;

comment on function pgr_biconnectedcomponents(text, out bigint, out bigint, out bigint) is 'pgr_biconnectedComponents
- Undirected graph
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_biconnectedComponents.html
';

alter function pgr_biconnectedcomponents(text, out bigint, out bigint, out bigint) owner to postgres;

