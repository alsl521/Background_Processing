create function pgr_withpointsdd(text, text, bigint, double precision, directed boolean DEFAULT true, driving_side character DEFAULT 'b'::bpchar, details boolean DEFAULT false, OUT seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
    RAISE WARNING 'pgr_withpointsdd(text,text,bigint,double precision,boolean,character,boolean) deprecated signature on 3.6.0';
    RETURN QUERY
    SELECT a.seq, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_withPointsDD(_pgr_get_statement($1), _pgr_get_statement($2), ARRAY[$3]::BIGINT[], $4, $5, $6, $7, false) AS a;
END;
$$;

comment on function pgr_withpointsdd(text, text, bigint, double precision, boolean, char, boolean, out integer, out bigint, out bigint, out double precision, out double precision) is 'pgRouting deprecated signature on v3.6.0
- Documentation: https://docs.pgrouting.org/latest/en/pgr_withPointsDD.html';

alter function pgr_withpointsdd(text, text, bigint, double precision, boolean, char, boolean, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

