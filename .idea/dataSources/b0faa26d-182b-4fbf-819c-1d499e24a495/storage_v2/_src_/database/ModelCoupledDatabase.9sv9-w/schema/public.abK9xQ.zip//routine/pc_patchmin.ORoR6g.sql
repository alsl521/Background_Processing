create function pc_patchmin(p pcpatch, attr text) returns numeric
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT _PC_PatchStat(p, 0, attr) $$;

alter function pc_patchmin(pcpatch, text) owner to postgres;

