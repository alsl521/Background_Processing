create function pgr_lengauertarjandominatortree(text, bigint, OUT seq integer, OUT vertex_id bigint, OUT idom bigint) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN

    RETURN QUERY
    SELECT a.seq, vid, a.idom
    FROM _pgr_lengauerTarjanDominatorTree(_pgr_get_statement($1),$2) AS a;
END;
$$;

comment on function pgr_lengauertarjandominatortree(text, bigint, out integer, out bigint, out bigint) is 'pgr_lengauerTarjanDominatorTree
- EXPERIMENTAL
- Directed graph
- Parameters:
  - edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_lengauerTarjanDominatorTree.html
';

alter function pgr_lengauertarjandominatortree(text, bigint, out integer, out bigint, out bigint) owner to postgres;

