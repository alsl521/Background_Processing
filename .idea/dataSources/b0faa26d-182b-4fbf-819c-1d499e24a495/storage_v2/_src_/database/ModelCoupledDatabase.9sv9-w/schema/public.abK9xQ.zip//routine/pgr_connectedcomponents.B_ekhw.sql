create function pgr_connectedcomponents(text, OUT seq bigint, OUT component bigint, OUT node bigint) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, component, node
    FROM _pgr_connectedComponents(_pgr_get_statement($1));
$$;

comment on function pgr_connectedcomponents(text, out bigint, out bigint, out bigint) is 'pgr_connectedComponents
- Undirected graph
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_connectedComponents.html
';

alter function pgr_connectedcomponents(text, out bigint, out bigint, out bigint) owner to postgres;

