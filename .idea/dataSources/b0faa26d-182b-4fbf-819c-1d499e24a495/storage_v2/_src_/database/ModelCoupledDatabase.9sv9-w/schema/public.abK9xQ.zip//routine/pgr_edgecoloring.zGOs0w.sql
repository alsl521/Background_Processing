create function pgr_edgecoloring(text, OUT edge_id bigint, OUT color_id bigint) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT a.edge_id, a.color_id
    FROM _pgr_edgeColoring(_pgr_get_statement($1)) AS a;
END;
$$;

comment on function pgr_edgecoloring(text, out bigint, out bigint) is 'pgr_edgeColoring
- EXPERIMENTAL
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_edgeColoring.html
';

alter function pgr_edgecoloring(text, out bigint, out bigint) owner to postgres;

