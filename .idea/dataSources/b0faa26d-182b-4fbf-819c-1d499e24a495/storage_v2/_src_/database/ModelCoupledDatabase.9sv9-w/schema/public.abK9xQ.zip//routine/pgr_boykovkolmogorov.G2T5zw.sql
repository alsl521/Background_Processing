create function pgr_boykovkolmogorov(text, bigint, anyarray, OUT seq integer, OUT edge bigint, OUT start_vid bigint, OUT end_vid bigint, OUT flow bigint, OUT residual_capacity bigint) returns SETOF record
    strict
    language sql
as
$$
        SELECT seq, edge_id, source, target, flow, residual_capacity
        FROM _pgr_maxflow(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], 2);
  $$;

comment on function pgr_boykovkolmogorov(text, bigint, anyarray, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) is 'pgr_boykovKolmogorov(One to Many)
- Directed graph
- Parameters:
  - edges SQL with columns: id, source, target, capacity [,reverse_capacity]
  - from vertex
  - to ARRAY[vertices identifiers]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_boykovKolmogorov.html
';

alter function pgr_boykovkolmogorov(text, bigint, anyarray, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) owner to postgres;

