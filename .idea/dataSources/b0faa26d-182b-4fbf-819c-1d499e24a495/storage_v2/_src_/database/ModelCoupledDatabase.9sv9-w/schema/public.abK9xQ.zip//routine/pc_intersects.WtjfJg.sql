create function pc_intersects(geometry, pcpatch) returns boolean
    language sql
as
$$
		SELECT public.PC_Intersects($2, $1)
	$$;

alter function pc_intersects(geometry, pcpatch) owner to postgres;

