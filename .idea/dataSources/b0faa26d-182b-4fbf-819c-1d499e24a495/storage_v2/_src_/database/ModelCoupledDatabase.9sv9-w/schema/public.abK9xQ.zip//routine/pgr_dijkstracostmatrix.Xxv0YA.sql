create function pgr_dijkstracostmatrix(text, anyarray, directed boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT a.start_vid, a.end_vid, a.agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), $2, $2, $3, TRUE) a;
$$;

comment on function pgr_dijkstracostmatrix(text, anyarray, boolean, out bigint, out bigint, out double precision) is 'pgr_dijkstraCostMatrix
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - ARRAY [vertices identifiers]
- Optional Parameters
    - directed := true
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_dijkstraCostMatrix.html
';

alter function pgr_dijkstracostmatrix(text, anyarray, boolean, out bigint, out bigint, out double precision) owner to postgres;

