create function pgr_dijkstra(text, bigint, bigint, directed boolean DEFAULT true, OUT seq integer, OUT path_seq integer, OUT start_vid bigint, OUT end_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, path_seq, start_vid, end_vid, node, edge, cost, agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], ARRAY[$3]::BIGINT[], $4, false, true);
$$;

comment on function pgr_dijkstra(text, bigint, bigint, boolean, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_dijkstra(One to One)
- Parameters:
   - Edges SQL with columns: id, source, target, cost [,reverse_cost]
   - From vertex identifier
   - To vertex identifier
- Optional Parameters
   - directed := true
- Documentation:
   - https://docs.pgrouting.org/latest/en/pgr_dijkstra.html
';

alter function pgr_dijkstra(text, bigint, bigint, boolean, out integer, out integer, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

