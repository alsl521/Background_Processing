create function pgr_maxcardinalitymatch(text, OUT edge bigint) returns SETOF bigint
    strict
    language sql
as
$$
SELECT edge
FROM _pgr_maxCardinalityMatch(_pgr_get_statement($1), false)
$$;

comment on function pgr_maxcardinalitymatch(text, out bigint) is 'pgr_maxCardinalityMatch
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_maxCardinalityMatch.html
';

alter function pgr_maxcardinalitymatch(text, out bigint) owner to postgres;

