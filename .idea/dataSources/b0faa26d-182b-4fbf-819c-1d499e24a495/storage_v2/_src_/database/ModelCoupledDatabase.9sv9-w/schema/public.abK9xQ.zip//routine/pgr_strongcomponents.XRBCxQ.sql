create function pgr_strongcomponents(text, OUT seq bigint, OUT component bigint, OUT node bigint) returns SETOF record
    strict
    language sql
as
$$
    SELECT seq, component, node
    FROM _pgr_strongComponents(_pgr_get_statement($1));
$$;

comment on function pgr_strongcomponents(text, out bigint, out bigint, out bigint) is 'pgr_strongComponents
- Directed graph
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_strongComponents.html
';

alter function pgr_strongcomponents(text, out bigint, out bigint, out bigint) owner to postgres;

