create function pgr_primdd(text, anyarray, double precision, OUT seq bigint, OUT depth bigint, OUT start_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
    IF $3 < 0 THEN
        RAISE EXCEPTION 'Negative value found on ''distance'''
        USING HINT = format('Value found: %s', $3);
    END IF;

    RETURN QUERY
    SELECT a.seq, a.depth, a.start_vid, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_prim(_pgr_get_statement($1), $2, 'DD', -1, $3::FLOAT) AS a;
END;
$$;

comment on function pgr_primdd(text, anyarray, double precision, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_primDD(Multiple Vertices)
- Undirected graph
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - From ARRAY[root vertices identifiers]
    - Distance
- Documentation:
    - https://docs.pgrouting.org/latest/en/pgr_primDD.html
';

alter function pgr_primdd(text, anyarray, double precision, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

